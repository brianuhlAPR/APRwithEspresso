<?php
/*
Plugin Name: Agile EE Custom Tax Solution
Description: Attempting to apply correct tax for event location but not on promo code amount
Version: 1.0
Author: Brian Uhl
*/

/**
 * PLEASE READ AND FOLLOW ALL INSTRUCTIONS IN CAPS
 *
 *
 * PLZ SEE ADDITIONAL INSTRUCTIONS IN FUNCTIONS BELOW
 *
 * bc_ee_determine_whether_to_apply_surcharge
 *
 * return void
 */


//function bc_ee_determine_whether_to_apply_surcharge() {
//    // CHANGE $surcharge_QST_ID VALUE TO MATCH THE ID OF YOUR QUESTION
//    $surcharge_QST_ID = 119;
//    if ( isset( $_REQUEST[ 'ee_reg_qstn' ] ) ) {
//        foreach ( $_REQUEST[ 'ee_reg_qstn' ] as $registrations ) {
//            if ( ! empty( $registrations ) ) {
//                foreach ( $registrations as $QST_ID => $response ) {
//                    if ( $QST_ID === $surcharge_QST_ID ) {
//                        switch ( $response ) {
//                            // CHANGE THESE TO EXACTLY MATCH THE ANSWER OPTIONS FOR YOUR QUESTION
//                            // THEN EDIT / ADD / DELETE THE FUNCTIONS BELOW
//                            // WHOSE NAMES MATCH THESE OPTIONS
//                            // YOU CAN ADD NEW OPTIONS, JUST MAKE SURE TO HAVE A CORRESPONDING
//                            // FUNCTION FOR SETTING THE SURCHARGE DETAILS
//                            case 'Ontario' :
//                                // apply the surcharge
//                                add_filter( 'FHEE__bc_ee_apply_transaction_surcharge__apply_surcharge', '__return_true' );
//                                // hook into function below to set surcharge details
//                                add_filter( 'FHEE__bc_ee_apply_transaction_surcharge__surcharge_details', 'ee_ontario_surcharge_details' );
//                                break;
//                            case 'Alberta' :
//                                // apply the surcharge
//                                add_filter( 'FHEE__bc_ee_apply_transaction_surcharge__apply_surcharge', '__return_true' );
//                                // hook into function below to set surcharge details
//                                add_filter( 'FHEE__bc_ee_apply_transaction_surcharge__surcharge_details', 'ee_alberta_surcharge_details' );
//                                break;
//                        }
//                    }
//                }
//            }
//        }
//    }
//}
//add_action( 'AHEE__EE_System__core_loaded_and_ready', 'bc_ee_determine_whether_to_apply_surcharge', 1 );

/**
 * EDIT THIS TO HOLD THE DETAILS FOR ONE OF YOUR ANSWER OPTIONS
 * @return array
 */
function ee_ontario_surcharge_details() {
    return array(
        'name'          => 'ontario hst',
        'code'          => 'ontario-hst',
        'description'   => 'ontario hst 13%',
        'percent'       => 13,
        'taxable'       => false,
    );
}
/**
 * EDIT THIS TO HOLD THE DETAILS FOR ONE OF YOUR ANSWER OPTIONS
 * @return array
 */
function ee_alberta_surcharge_details() {
    return array(
        'name'          => 'alberta hst',
        'code'          => 'alberta-hst',
        'description'   => 'alberta hst 5%',
        'percent'       => 5,
        'taxable'       => false,
    );
}
/**
 * DO NOT EDIT ANYTHING EXCEPT DEFAULT SURCHARGE DETAILS
 *
 * bc_ee_apply_transaction_surcharge
 *
 * @param \EE_Checkout $checkout
 * @return \EE_Checkout
 */
function bc_ee_apply_transaction_surcharge( EE_Checkout $checkout ) {
    // DEFAULT SURCHARGE DETAILS - EDIT THIS
    $surcharge_details = apply_filters(
        'FHEE__bc_ee_apply_transaction_surcharge__surcharge_details',
        array(
            //  name for surcharge that will be displayed
            'name'        => 'gst',
            // unique code used to identify surcharge in the db
            'code'        => 'default-gst',
            // description for line item
            'description' => 'default gst',
            // percentage amount
            'percent'     => 50,
            // whether or not tax is applied on top of the surcharge
            'taxable'     => false,
        )
    );

    if ( $checkout instanceof EE_Checkout ) {
        $transaction = $checkout->transaction;
        var_dump($transaction);
        if ( $transaction instanceof EE_Transaction ) {
            $registrations = $transaction->registrations();
            $registration = reset( $registrations );
            if ( $registration instanceof EE_Registration ) {
                $event = $registration->event();
                if ( $event instanceof EE_Event ) {
                    $VNU_ID = espresso_venue_id( $event->ID() ); //Get venue id
                    $VNU_Address = espresso_venue_address('multiline', $VNU_ID );
                    var_dump($VNU_Address);
                }
            }
        }
    }

    // STOP EDITING
    // apply the surcharge ?
    // remove true ) { from below after testing
    if ( true ) { //! apply_filters( 'FHEE__bc_ee_apply_transaction_surcharge__apply_surcharge', false )) {
        return $checkout;
    }
    // verify checkout
    if ( ! $checkout instanceof EE_Checkout ) {
        return $checkout;
    }
    // verify cart
    $cart = $checkout->cart;
    if ( ! $cart instanceof EE_Cart ) {
        return $checkout;
    }
    // verify grand total line item
    $grand_total = $cart->get_grand_total();
    if ( ! $grand_total instanceof EE_Line_Item ) {
        return $checkout;
    }
    // has surcharge already been applied ?
    $existing_surcharge = $grand_total->get_child_line_item( $surcharge_details[ 'code' ] );
    if ( $existing_surcharge instanceof EE_Line_Item ) {
        return $checkout;
    }
    EE_Registry::instance()->load_helper( 'Line_Item' );
    $pre_tax_subtotal = EEH_Line_Item::get_pre_tax_subtotal( $grand_total );
    $pre_tax_subtotal->add_child_line_item(
        EE_Line_Item::new_instance( array(
            'LIN_name'       => $surcharge_details[ 'name' ],
            'LIN_desc'       => $surcharge_details[ 'description' ],
            'LIN_unit_price' => 0,
            'LIN_percent'    => $surcharge_details[ 'percent' ],
            'LIN_quantity'   => NULL,
            'LIN_is_taxable' => $surcharge_details[ 'taxable' ],
            'LIN_order'      => 0,
            'LIN_total'      => (float) ( $percentage_amount * ( $pre_tax_subtotal->total() / 100 ) ),
            'LIN_type'       => EEM_Line_Item::type_line_item,
            'LIN_code'       => $surcharge_details[ 'code' ],
        ) )
    );
    $grand_total->recalculate_total_including_taxes();
    return $checkout;
}
add_filter( 'FHEE__EED_Single_Page_Checkout___initialize_checkout__checkout', 'bc_ee_apply_transaction_surcharge' );